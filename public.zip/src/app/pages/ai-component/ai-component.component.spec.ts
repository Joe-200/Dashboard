import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AiComponent } from './ai-component.component';

describe('AiComponentComponent', () => {
  let component: AiComponent;
  let fixture: ComponentFixture<AiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AiComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
